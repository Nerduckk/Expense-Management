package com.mycompany.appquanlychitieu.service;

import com.mycompany.appquanlychitieu.model.*;
import java.util.List;

public class DataStore {
    private static final String FILE_ACCOUNTS = "accounts.dat";
    private static final String FILE_CATEGORIES = "categories.dat";
    private static final String FILE_TRANSACTIONS = "transactions.dat";
    private static final String FILE_USERS = "users.dat";
    public static List<User> users;
    public static List<Account> accounts;
    public static List<Category> categories;
    public static List<AbstractTransaction> transactions;

    public static void loadData() {
    // ... đoạn load accounts, users, transactions giữ nguyên

    categories = FileHelper.loadFromFile(FILE_CATEGORIES);
    if (categories == null) {
        categories = new java.util.ArrayList<>();
    }

    // ==== Đảm bảo luôn có ít nhất 1 Category INCOME và 1 Category EXPENSE ====
    boolean hasIncome = categories.stream()
            .anyMatch(c -> c.getType() == CategoryType.INCOME);
    boolean hasExpense = categories.stream()
            .anyMatch(c -> c.getType() == CategoryType.EXPENSE);

    boolean changed = false;

    if (!hasIncome) {
        Category luong = new Category(
                "Lương",
                CategoryType.INCOME,
                "money",
                "#4CAF50",
                null
        );
        categories.add(luong);
        changed = true;
    }

    if (!hasExpense) {
        Category anUong = new Category(
                "Ăn uống",
                CategoryType.EXPENSE,
                "restaurant",
                "#F44336",
                null
        );
        categories.add(anUong);
        changed = true;
    }

    if (changed) {
        FileHelper.saveToFile(categories, FILE_CATEGORIES);
    }
}
    public static void saveData() {
        FileHelper.saveToFile(accounts, FILE_ACCOUNTS);
        FileHelper.saveToFile(categories, FILE_CATEGORIES);
        FileHelper.saveToFile(transactions, FILE_TRANSACTIONS);
        FileHelper.saveToFile(users, FILE_USERS);
    }
}