package com.mycompany.appquanlychitieu.service;

import com.mycompany.appquanlychitieu.model.User;
import java.util.Optional;

public class AuthService {

    public User login(String email, String rawPassword) {
        if (email == null || rawPassword == null) return null;

        Optional<User> opt = DataStore.users.stream()
                .filter(u -> email.equalsIgnoreCase(u.getEmail()))
                .findFirst();

        if (opt.isPresent()) {
            User u = opt.get();
            if (rawPassword.equals(u.getPasswordHash())) {
                return u;
            }
        }
        return null;
    }
}
