package com.mycompany.appquanlychitieu.service;

import com.mycompany.appquanlychitieu.model.*;
import java.util.List;

public class DataStore {
    // Tên file lưu trữ
    private static final String FILE_ACCOUNTS = "accounts.dat";
    private static final String FILE_CATEGORIES = "categories.dat";
    private static final String FILE_TRANSACTIONS = "transactions.dat";
    // Có thể thêm User, Debt...

    // Dữ liệu trong RAM (Global)
    public static List<Account> accounts;
    public static List<Category> categories;
    public static List<AbstractTransaction> transactions;

    // Khởi động: Đọc từ file lên RAM
    public static void loadData() {
        accounts = FileHelper.loadFromFile(FILE_ACCOUNTS);
        categories = FileHelper.loadFromFile(FILE_CATEGORIES);
        transactions = FileHelper.loadFromFile(FILE_TRANSACTIONS);
        System.out.println("--- Đã tải xong dữ liệu ---");
    }

    // Lưu toàn bộ RAM xuống file
    public static void saveData() {
        FileHelper.saveToFile(accounts, FILE_ACCOUNTS);
        FileHelper.saveToFile(categories, FILE_CATEGORIES);
        FileHelper.saveToFile(transactions, FILE_TRANSACTIONS);
    }
}