package com.mycompany.appquanlychitieu.service;

import com.mycompany.appquanlychitieu.model.*;
import java.math.BigDecimal;

public class TransactionService {

    // Hàm tạo giao dịch mới (Xử lý chung cho mọi loại)
    public void addTransaction(AbstractTransaction txn) {
        
        // 1. Validate dữ liệu (Nếu bạn đã thêm hàm validate() vào BaseEntity)
        // txn.validate(); 

        // 2. Xử lý trừ tiền/cộng tiền (Business Logic)
        processBalanceUpdate(txn);

        // 3. Thêm vào danh sách chung
        DataStore.transactions.add(txn);

        // 4. Lưu thay đổi xuống ổ cứng ngay lập tức
        DataStore.saveData(); 
        System.out.println("Giao dịch đã được ghi nhận!");
    }

    // Logic cập nhật số dư tài khoản
    private void processBalanceUpdate(AbstractTransaction txn) {
        // Trường hợp 1: Chuyển khoản (Transfer)
        if (txn instanceof TransferTransaction) {
            TransferTransaction tTxn = (TransferTransaction) txn;
            // Logic: Trừ nguồn, Cộng đích
            BigDecimal totalDeduct = tTxn.getAmount().add(tTxn.getTransferFee());
            tTxn.getSourceAccount().debit(totalDeduct);
            tTxn.getToAccount().credit(tTxn.getAmount());
        } 
        // Trường hợp 2: Giao dịch thường & Nợ (Normal & Debt)
        else {
            // Dùng tính đa hình isIncome/isExpense
            Account acc = txn.getSourceAccount();
            if (txn.isExpense()) {
                acc.debit(txn.getAmount());
            } else if (txn.isIncome()) {
                acc.credit(txn.getAmount());
            }
            // Nếu không phải thu cũng không phải chi (VD: ghi nợ nhưng chưa trả tiền), thì ko update balance
        }
    }
    
    // Hàm xóa giao dịch (Sẽ hoàn tiền lại)
    public void deleteTransaction(AbstractTransaction txn) {
        // Logic hoàn tiền (Revert) phức tạp hơn, tạm thời chỉ xóa khỏi list
        DataStore.transactions.remove(txn);
        DataStore.saveData();
    }
}