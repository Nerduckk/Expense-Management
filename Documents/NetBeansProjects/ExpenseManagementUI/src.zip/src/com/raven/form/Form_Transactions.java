package com.raven.form;

import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Form_Transactions extends javax.swing.JPanel {

    public Form_Transactions() {
        initComponents();
    }

    private void initComponents() {
        setOpaque(false);

        javax.swing.JLabel lbl = new javax.swing.JLabel();
        lbl.setText("Danh sách giao dịch");
        lbl.setFont(new java.awt.Font("sansserif", 1, 14));
        lbl.setForeground(new Color(4, 72, 210));

        JScrollPane scroll = new JScrollPane();
        JTable tbl = new JTable();

        tbl.setModel(new DefaultTableModel(
            new Object[][]{},
            new String[]{
                "Ngày", "Loại", "Số tiền", "Ví", "Ghi chú"
            }
        ) {
            boolean[] canEdit = new boolean[]{
                false, false, false, false, false
            };
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });

        scroll.setViewportView(tbl);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lbl)
                        .addComponent(scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE))
                    .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lbl)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
                    .addContainerGap())
        );
    }
}
